<?php

namespace App\Models;

class Distributor extends BaseModel
{
    protected $fillable = [
        'name',
        'contact_email',
    ];
}
