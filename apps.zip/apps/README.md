
<div dir="rtl">

## 📋 نظرة عامة

**STC AI-VAP** أعيد تنظيمها لتصبح حزمة احترافية سهلة التركيب على نمط CodeCanyon:

### 🌐 1. Laravel SaaS (Cloud + Web معًا)
- **المسار:** `apps/cloud-laravel`
- **التقنية:** Laravel 11 + Sanctum + واجهة Blade/Vue مدمجة.
- **النشر:** VPS (Nginx + PHP-FPM) مع قاعدة بيانات جاهزة للاستيراد وبيانات تجريبية.

### 🖥️ 2. Edge Server (السيرفر المحلي)
- **المسار:** `apps/edge-server`
- **التقنية:** Python (خدمة REST محلية) + SQLite/PostgreSQL محلي لتشغيل نماذج الـAI والفيديو والتكاملات، مع أداة توليد EXE عبر PyInstaller.
- **النشر:** جهاز الموقع المحلي (Windows EXE أو Linux خدمة systemd).

### 📱 3. Mobile App (تطبيق الجوال)
- **المسار:** `apps/mobile-app`
- **التقنية:** Flutter (Android/iOS)
- **النشر:** Play Store / App Store أو ملفات APK/IPA

## 📚 أدلة النشر والتشغيل
- [دليل تنصيب Laravel SaaS + Edge EXE](docs/LARAVEL_SAAS_SETUP.md)
- [الدليل الاحترافي لتثبيت الـCloud والـEdge](docs/CLOUD_EDGE_INSTALLATION.md)
- [دليل التكامل مع السحابة](docs/CLOUD_INTEGRATION_GUIDE.md)
- [دليل التجهيز والتنزيل](docs/DOWNLOAD.md)
- [مخطط الحزم والمسارات](docs/PACKAGE_LAYOUT.md)
- [شرح مجلد `apps` ومحتوياته](docs/APPS_OVERVIEW.md)
- [التنصيب السريع بنمط SaaS مع بيانات تجريبية](docs/SAAS_EASY_INSTALL.md)
- [صناعة مثبت السيرفر المحلي بصيغة تنفيذية](docs/EDGE_INSTALLER.md)
- [قائمة التحقق النهائية قبل التسليم](docs/END_TO_END_CHECKLIST.md)
- **قاعدة بيانات جاهزة**: ملف SQL كامل مع بيانات تجريبية تحت `apps/cloud-laravel/database/schema.sql` (استيراد مباشر إلى PostgreSQL)

---

## ✨ المميزات الرئيسية

### 🤖 9 موديولات ذكاء اصطناعي

1. **🔥 كشف الحرائق والدخان**
   - كشف فوري للحرائق
   - تنبيهات لحظية
   - تكامل مع أنظمة الإطفاء

2. **👤 التعرف على الوجوه**
   - دقة 99.5%
   - تسجيل وجوه غير محدود
   - تصنيفات: موظف، VIP، زائر، قائمة سوداء

3. **👥 عداد الأشخاص**
   - احصاء دقيق للدخول/الخروج
   - تحليل حركة المرور
   - إحصائيات ساعية/يومية

4. **🚗 التعرف على المركبات (ANPR)**
   - قراءة لوحات السيارات (عربي + إنجليزي)
   - فتح بوابات تلقائي للـ VIP
   - سجل الدخول/الخروج

5. **✅ نظام الحضور والانصراف**
   - تسجيل تلقائي بالوجه
   - حساب ساعات العمل
   - تقارير الحضور

6. **🚨 كشف التسلل**
   - مراقبة المناطق المحظورة
   - كشف المتسللين
   - تنبيهات فورية

7. **👨👩 كشف الجنس والعمر**
   - تحليل ديموغرافي
   - إحصائيات الزوار
   - تحليلات التسويق

8. **🦺 كشف معدات السلامة (PPE)**
   - خوذة، سترة، قفازات
   - تنبيه عند الانتهاكات
   - للمصانع ومواقع البناء

9. **🔫 كشف الأسلحة**
   - كشف أسلحة نارية
   - تنبيهات حرجة فورية
   - إجراءات أمنية تلقائية

### 🔗 التكاملات

- **Arduino** - التحكم في الأبواب والبوابات
- **Raspberry Pi GPIO** - التحكم في الأجهزة
- **MQTT** - التكامل مع أنظمة IoT
- **Modbus TCP** - التكامل الصناعي
- **HTTP REST** - أنظمة خارجية
- **TCP Socket** - اتصالات مخصصة

### 📢 قنوات الإشعارات

- **Push Notifications** - إشعارات فورية للموبايل
- **SMS** - رسائل نصية
- **WhatsApp** - رسائل واتساب
- **Phone Calls** - مكالمات صوتية
- **Email** - بريد إلكتروني

---

## 📦 محتويات المشروع

```
project/
├── 📂 apps/
│   ├── cloud-laravel/    # Laravel (Cloud + Web) مع قاعدة بيانات جاهزة للنشر على الـ VPS
│   ├── edge-server/      # FastAPI + AI + تكاملات الهاردوير (محلي مع توليد EXE)
│   └── mobile-app/       # Flutter تطبيق الموبايل
│
├── 📂 docs/              # أدلة التشغيل والتكامل والتنزيل
├── 📂 scripts/           # سكربتات مساعدة (التغليف، الأدوات)
└── 📄 README.md          # هذا الملف
```

> ✅ **تنظيم نهائي بثلاث حزم فقط**: لا توجد مجلدات Legacy مثل `web-portal/` أو `cloud-server/`. النسخة الحالية تحتوي فقط على الحزم الثلاث المطلوبة (الكلاود Laravel، السيرفر المحلي، وتطبيق الجوال) لضمان بساطة التثبيت والترابط الكامل بين المكونات.

---

## 🚀 البدء السريع

### 1️⃣ Cloud Server API (VPS)

```bash
cd apps/cloud-laravel
cp .env.example .env
composer install --no-dev
php artisan key:generate
psql -U <user> -d <db> -f database/schema.sql  # تحميل البيانات التجريبية
npm install && npm run build
php artisan serve --host 0.0.0.0 --port 8000
```

### 2️⃣ Edge Server (محلي)

```bash
cd apps/edge-server
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env  # عدّل CLOUD_API_URL, LICENSE_KEY...
uvicorn main:app --host 0.0.0.0 --port 8080
```

### 3️⃣ Mobile App (Flutter)

```bash
cd apps/mobile-app
flutter pub get
flutter run
flutter build apk --release
```

---

## 📚 التوثيق

### 📖 أدلة التثبيت

- **[CLOUD_EDGE_INSTALLATION](docs/CLOUD_EDGE_INSTALLATION.md)** – تثبيت الـCloud على الـVPS والـEdge محليًا مع أمثلة systemd/Nginx.
- **[CLOUD_INTEGRATION_GUIDE](docs/CLOUD_INTEGRATION_GUIDE.md)** – ربط الـEdge بالـCloud وAPI التحكم.
- **[DOWNLOAD](docs/DOWNLOAD.md)** – الحصول على آخر أرشيف وإعادة التغليف.
- **[PACKAGE_LAYOUT](docs/PACKAGE_LAYOUT.md)** – شرح المجلدات المنفصلة ومسارات النشر.



## 🔧 المتطلبات المختصرة

### Laravel SaaS (VPS)
- Ubuntu 22.04 LTS أو Debian 12
- PHP 8.2+, Composer, Node.js 18+, PostgreSQL 14+
- Nginx + PHP-FPM للنشر الإنتاجي

### Edge Server (محلي)
- Ubuntu/Debian حديث
- Python 3.11+, FFmpeg, libgl1، وتعريفات GPU إن وجدت
- مساحة تخزين محلية للوسائط

### Mobile App
- Flutter SDK 3.16+
- Android Studio/Xcode للحزم

---

## 🎯 حالات الاستخدام

### 🏢 المباني التجارية
- مراقبة الدخول والخروج
- نظام حضور وانصراف
- كشف التسلل
- إدارة مواقف السيارات

### 🏭 المصانع
- كشف معدات السلامة (PPE)
- مراقبة المناطق الخطرة
- نظام حضور العمال
- كشف الحرائق

### 🏬 المحلات التجارية
- عداد الزوار
- تحليل ديموغرافي
- تحليل حركة المرور
- منع السرقات

### 🏠 المجمعات السكنية
- التحكم في البوابات
- التعرف على السكان والزوار
- مراقبة المناطق العامة
- كشف التسلل

### 🏥 المستشفيات
- نظام دخول المرضى
- مراقبة المناطق الحساسة
- كشف الحرائق
- إدارة مواقف السيارات

---

## 🔐 الأمان

### Cloud
- ✅ Laravel Sanctum + API Keys للمصادقة
- ✅ HTTPS/TLS عبر Nginx
- ✅ عزل قاعدة البيانات على الـVPS
- ✅ Rate Limiting (Nginx)

### Edge Server
- ✅ Hardware ID Authentication
- ✅ Local Network Isolation
- ✅ No Video Storage in Cloud
- ✅ تخزين ميتاداتا فقط عند المزامنة

### Mobile App
- ✅ Secure Storage
- ✅ Certificate Pinning
- ✅ Biometric Auth Support

---

## 📊 الأداء (إرشادي)

- **معالجة الفيديو (Edge):** يستهدف حتى 30 FPS لكل كاميرا مع توزيع الحمل على عدة أجهزة Edge.
- **قواعد البيانات:**
  - Cloud: PostgreSQL مدار على الـVPS.
  - Edge: SQLite افتراضيًا مع خيار PostgreSQL محلي.
- **التخزين:** الوسائط تبقى محليًا على الـEdge، ويُرسل للسحابة الميتاداتا فقط.

---

## 🧪 الاختبار

```bash
# Cloud Laravel (داخل apps/cloud-laravel)
composer install --no-dev --optimize-autoloader
npm install && npm run build
php artisan test

# Edge Server (داخل apps/edge-server)
python -m compileall .

# Mobile App (داخل apps/mobile-app)
flutter test
```

### اختبار الـ API

```bash
# Edge Server health
curl http://localhost:8080/health

# Cloud Server licensing probe (Laravel)
curl -X POST http://<VPS_IP>:8000/api/license/validate -d '{"license_key":"DEMO"}' -H "Content-Type: application/json"
```

---

## 🐛 استكشاف الأخطاء

### Cloud لا يعمل؟

```bash
# 1. تحقق من .env
cat .env

# 2. تحقق من قاعدة البيانات/الاتصال
pg_isready -d "$CLOUD_DATABASE_URL"  # أو sqlite3 cloud.db '.tables'

# 3. راجع سجلات الخدمة
sudo journalctl -u stc-cloud -n 50

# 4. راجع browser console
# F12 → Console
```

### Edge Server offline؟

```bash
# 1. فحص الحالة
sudo systemctl status stc-edge

# 2. عرض اللوجات
sudo journalctl -u stc-edge -n 50

# 3. إعادة التشغيل
sudo systemctl restart stc-edge
```

### الكاميرا لا تعمل؟

```bash
# 1. اختبار RTSP
ffplay rtsp://username:password@camera-ip:554/stream

# 2. فحص الشبكة
ping camera-ip

# 3. راجع اللوجات
grep "camera-id" /var/log/stc-edge/app.log
```

📖 **دليل استكشاف الأخطاء الكامل:** راجع [docs/TESTING_GUIDE.md](docs/TESTING_GUIDE.md)

---

## 📞 الدعم الفني

### قنوات الدعم

- **📧 البريد الإلكتروني:** support@stc-solutions.com
- **📞 الهاتف:** +966 11 000 0000
- **🌐 الموقع:** https://stc-solutions.com
- **💬 الدردشة:** متوفرة في التطبيق

### ساعات العمل
- **الأحد - الخميس:** 9:00 صباحاً - 5:00 مساءً
- **الجمعة - السبت:** مغلق
- **الطوارئ:** 24/7 (للعملاء المميزين)

---

## 📄 الترخيص

جميع الحقوق محفوظة © 2024 **STC Solutions**

هذا المشروع مملوك لشركة STC Solutions ومحمي بموجب قوانين الملكية الفكرية.

---

## 🙏 شكر خاص

تم بناء هذا المشروع باستخدام:

- [Laravel](https://laravel.com/) - Cloud + Web
- [Flutter](https://flutter.dev/) - Mobile framework
- [Python](https://www.python.org/) + FastAPI محليًا لخدمة الـEdge
- [PostgreSQL](https://www.postgresql.org/) - Database
- [OpenCV](https://opencv.org/) - Computer vision
- [TensorFlow](https://www.tensorflow.org/) - Machine learning

---

## 📈 إصدارات المشروع

### Version 1.0.0 (Current)
- ✅ 9 AI Modules
- ✅ Cloud Platform
- ✅ Edge Server
- ✅ Mobile App
- ✅ 6 Integration Types
- ✅ 5 Notification Channels

### Roadmap (المستقبل)
- 🔜 Dashboard Mobile Widgets
- 🔜 Voice Control
- 🔜 Advanced Analytics
- 🔜 Multi-language Support
- 🔜 Cloud Recording
- 🔜 AI Model Training Interface

---

## 🎓 تعليم الاستخدام

### للمستخدمين الجدد

1. **ابدأ مع الدليل:** اقرأ [docs/CLOUD_EDGE_INSTALLATION.md](docs/CLOUD_EDGE_INSTALLATION.md)
2. **افهم الهيكل:** راجع [docs/PACKAGE_LAYOUT.md](docs/PACKAGE_LAYOUT.md)
3. **شاهد الفيديوهات:** قريباً على YouTube
4. **جرب النسخة التجريبية:** demo.stc-ai-vap.com

### للمطورين

1. **استكشف الكود:** راجع الـ source code
2. **افهم الـ API:** راجع API documentation
3. **المساهمة:** اتصل بنا للمساهمة
4. **الإبلاغ عن Bugs:** support@stc-solutions.com

---

<div align="center">

**🌟 صُنع بـ ❤️ في المملكة العربية السعودية 🇸🇦**

**STC Solutions - نحول الرؤية إلى واقع**

</div>

</div>
