# STC AI-VAP Edge Server

خادم الـEdge مسؤول عن تشغيل نماذج الذكاء الاصطناعي، معالجة الفيديو، التكاملات (Modbus/Arduino/GPIO/MQTT)، وتخزين الوسائط محليًا مع مزامنة الميتاداتا فقط إلى السحابة.

## 🚀 التشغيل السريع
1) تثبيت المتطلبات
```bash
pip install -r requirements.txt
```

2) ضبط البيئة
```bash
cp .env.example .env
# عدّل CLOUD_API_URL و LICENSE_KEY وباقي الإعدادات حسب موقعك
```
أو استخدم معالج الإعداد عبر المتصفح: `http://localhost:8080/setup`

3) التشغيل
```bash
uvicorn main:app --host 0.0.0.0 --port 8080
```

## ⚙️ المتغيرات البيئية الأساسية
| المتغير | الوصف | القيمة الافتراضية |
| --- | --- | --- |
| CLOUD_API_URL | رابط خادم السحابة (FastAPI على الـVPS) | Required |
| CLOUD_API_KEY | مفتاح الوصول للـAPI (اختياري إذا تم تفعيله) | فارغ |
| LICENSE_KEY | مفتاح الترخيص المرتبط بالمنظمة والـEdge | Required |
| SERVER_HOST | عنوان الاستماع | 0.0.0.0 |
| SERVER_PORT | المنفذ | 8080 |
| SYNC_INTERVAL | فترة إعادة محاولة المزامنة (ثواني) | 30 |
| HEARTBEAT_INTERVAL | فترة نبضات الحالة (ثواني) | 60 |
| DATA_DIR | مجلد البيانات (الوسائط/الكاش/الطابور) | data |
| LOG_DIR | مجلد السجلات | logs |
| LOG_LEVEL | مستوى السجلات | INFO |
| MAX_CAMERAS | الحد الأقصى للكاميرات | 16 |
| PROCESSING_FPS | معدل الإطارات للتحليل | 5 |
| FACE_CONFIDENCE | عتبة ثقة الوجوه | 0.6 |
| OBJECT_CONFIDENCE | عتبة الكائنات | 0.5 |
| FIRE_CONFIDENCE | عتبة الحرائق | 0.7 |

> يتم حفظ التحقق من الترخيص محليًا بما في ذلك فترة سماح 14 يومًا بعد انتهاء الصلاحية للسماح بالتشغيل أوفلاين.

## 🔗 نقاط الـAPI الرئيسية
- `GET /` و`/health` — فحوصات الحالة.
- `GET /setup` — معالج التهيئة الأولى (الربط مع السحابة + الترخيص).
- `GET /api/v1/status` — حالة النظام التفصيلية.
- `GET /api/v1/cameras` — قائمة الكاميرات.
- `GET /api/v1/modules` — قائمة الموديولات وخصائصها.
- `GET /api/v1/system/info` — معلومات العتاد والنظام.

## 🛠️ أوامر الخدمة (Windows)
```bash
python main.py install   # تثبيت كخدمة
python main.py remove    # إزالة الخدمة
net start STCAIVAPEdgeServer
net stop STCAIVAPEdgeServer
```

## 📦 البناء (Windows)
1) تثبيت المتطلبات الإضافية:
```bash
pip install pyinstaller pywin32
```
2) بناء التنفيذي:
```bash
pyinstaller edge_server.spec
```
3) بناء المُثبّت (Inno Setup مطلوب):
```bash
iscc installer/setup.iss
```
النتيجة في `dist/installer/`.

## 💬 الدعم
- Email: support@stc-solutions.com
- Website: https://stc-solutions.com
