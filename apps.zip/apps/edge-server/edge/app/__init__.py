"""
Edge Server Application Package
"""
