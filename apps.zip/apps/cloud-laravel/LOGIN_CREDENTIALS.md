# بيانات الدخول - Login Credentials

## 🔐 بيانات الدخول للمستخدمين

### 1. Super Administrator (المدير العام)
**الدور**: إدارة كاملة للنظام

```
البريد الإلكتروني: superadmin@demo.local
كلمة المرور: Super@12345
```

**الصلاحيات**:
- إدارة جميع المؤسسات
- إدارة جميع المستخدمين
- إعدادات النظام الكاملة
- إدارة التراخيص
- جميع الصلاحيات

---

### 2. Organization Owner (صاحب المؤسسة)
**الدور**: مالك المؤسسة - إدارة كاملة للمؤسسة

**من قاعدة البيانات الكاملة (stc_cloud_mysql_complete.sql)**:
```
البريد الإلكتروني: owner@demo-org.com
كلمة المرور: password (الافتراضي من Laravel)
```

**أو من DatabaseSeeder (إذا تم إنشاؤه)**:
```
البريد الإلكتروني: owner@org1.local
كلمة المرور: Owner@12345
```

**الصلاحيات**:
- إدارة المؤسسة بالكامل
- إدارة المستخدمين في المؤسسة
- إدارة الكاميرات والسيرفرات
- إدارة الأحداث والتنبيهات
- إعدادات المؤسسة
- التقارير والتحليلات

---

### 3. Organization Admin (مدير المؤسسة)
**الدور**: مدير المؤسسة

```
البريد الإلكتروني: admin@org1.local
كلمة المرور: Admin@12345
```

**الصلاحيات**:
- إدارة المستخدمين في المؤسسة
- إدارة الكاميرات والسيرفرات
- إدارة الأحداث والتنبيهات
- التقارير والتحليلات

---

### 4. Operator (المشغل)
**الدور**: مشغل النظام

```
البريد الإلكتروني: operator@org1.local
كلمة المرور: Operator@12345
```

**الصلاحيات**:
- عرض الكاميرات
- إدارة الأحداث
- الرد على التنبيهات
- عرض التقارير

---

### 5. Viewer (المشاهد)
**الدور**: مشاهد فقط

```
البريد الإلكتروني: viewer@org1.local
كلمة المرور: Viewer@12345
```

**الصلاحيات**:
- عرض الكاميرات فقط
- عرض الأحداث
- عرض التقارير
- لا يمكنه التعديل

---

## 📝 ملاحظات مهمة

1. **Organization Owner** هو المستخدم الذي يملك المؤسسة وله جميع الصلاحيات داخل المؤسسة
2. جميع المستخدمين ينتمون إلى **Organization ID: 1** (Demo Corporation)
3. كلمات المرور مشفرة باستخدام bcrypt
4. جميع المستخدمين مفعّلين (`is_active = true`)

## 📋 بيانات الدخول من SQL Dump (محدثة)

إذا استخدمت `stc_cloud_mysql_canonical_latest.sql` أو `stc_cloud_mysql_complete_latest.sql`:

### Super Admin:
```
Email: superadmin@demo.local
Password: Super@12345
Role: super_admin
is_super_admin: TRUE
Organization ID: NULL
```

### Organization Owner (Organization ID: 1):
```
Email: owner@demo-org.com
Password: password
Name: صاحب المؤسسة
Role: owner
is_super_admin: FALSE
```

### Organization Admin (Organization ID: 1):
```
Email: admin@demo-org.com
Password: password
Name: مدير الأمن
Role: admin
is_super_admin: FALSE
```

### Editor (Organization ID: 1):
```
Email: editor@demo-org.com
Password: password
Name: محرر
Role: editor
is_super_admin: FALSE
```

## 🔄 إنشاء مستخدم صاحب مؤسسة جديد

إذا لم يكن موجوداً، يمكنك إنشاؤه من SQL:

```sql
INSERT INTO `users` (
    `organization_id`, 
    `name`, 
    `email`, 
    `password`, 
    `role`, 
    `is_active`, 
    `phone`,
    `created_at`, 
    `updated_at`
) VALUES (
    1,
    'صاحب المؤسسة',
    'owner@org1.local',
    '$2y$12$YOUR_HASHED_PASSWORD_HERE',
    'owner',
    true,
    '+966 50 000 0005',
    NOW(),
    NOW()
);
```

أو استخدام Laravel Tinker:

```php
php artisan tinker

$user = \App\Models\User::create([
    'organization_id' => 1,
    'name' => 'صاحب المؤسسة',
    'email' => 'owner@org1.local',
    'password' => Hash::make('Owner@12345'),
    'role' => 'owner',
    'is_active' => true,
    'phone' => '+966 50 000 0005',
]);
```

## 🔑 كلمات المرور المشفرة

### من DatabaseSeeder:
- `Super@12345` → `$2y$12$v.6QuWtKrrg7YZ8wTWoWxOIYAGnq1xCrA6V8TS8QbDeWUHsHFCpY.`
- `Admin@12345` → `$2y$12$jX9.JiiNxIzibIXlwwM3Quq7/wQzDTr8tbllpOOY9V.wzwtg9424y`
- `Owner@12345` → يمكن إنشاؤه باستخدام `Hash::make('Owner@12345')`
- `Operator@12345` → `$2y$12$jX9.JiiNxIzibIXlwwM3Quq7/wQzDTr8tbllpOOY9V.wzwtg9424y`
- `Viewer@12345` → `$2y$12$jX9.JiiNxIzibIXlwwM3Quq7/wQzDTr8tbllpOOY9V.wzwtg9424y`

### من SQL Dump (stc_cloud_mysql_complete.sql):
- جميع المستخدمين يستخدمون كلمة المرور الافتراضية: `password`
- Hash: `$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi`

## ⚠️ تحذير أمني

- **لا تستخدم هذه البيانات في Production!**
- **غيّر جميع كلمات المرور بعد التثبيت!**
- **استخدم كلمات مرور قوية ومعقدة!**

